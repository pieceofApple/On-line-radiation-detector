#ifndef __BSP_GPT_INPUT_CAPTURE_H
#define __BSP_GPT_INPUT_CAPTURE_H
#include "hal_data.h"

void GPT_InputCapture_Init(void);

#endif
