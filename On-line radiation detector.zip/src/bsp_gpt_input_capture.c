#include "bsp_gpt_input_capture.h"
#include "stdio.h"


/*  当前选用输入捕获引脚 GTIOC7A P603 */


timer_info_t info;  //用于获取定时器参数信息
uint32_t period;    //输入捕获计数器的计数周期

/* 保存所测量的PWM信号的信息 */
uint32_t pwm_period;            //PWM周期
uint32_t pwm_high_level_time;   //PWM高电平的时间
uint32_t pwm_freq;              //PWM频率
uint32_t pwm_duty;              //PWM占空比

uint32_t pulse_up_count=0;
uint32_t pulse_count=0;
uint32_t pulse_up_count_1s=0;
uint32_t pulse_1s=0;
/* GPT初始化函数 */
void GPT_InputCapture_Init(void)
{
    /* 初始化 GPT 模块 */
    R_GPT_Open(&g_timer_gpt7_ctrl, &g_timer_gpt7_cfg);
    
    /* 获取当前参数 */
    (void) R_GPT_InfoGet(&g_timer_gpt7_ctrl, &info);
    /* 获取计数周期：GPT计数器一个周期的计数次数 */
    period = info.period_counts;
    
    /* 使能输入捕获 */
	R_GPT_Enable(&g_timer_gpt7_ctrl);
    
    /* 启动 GPT 定时器 */
    R_GPT_Start(&g_timer_gpt7_ctrl);
}
/* 使用寄存器来实现 LED灯翻转 */
#define LED1_TOGGLE R_PORT4->PODR ^= 1<<(BSP_IO_PORT_04_PIN_00 & 0xFF)

/* GPT 输入捕获中断回调函数 */
void gpt7_input_capture_callback(timer_callback_args_t * p_args)
{
    static uint32_t overflow_times;     //计数器溢出次数

    switch(p_args->event)
    {
        /* 捕获到上升沿 -- 有可能是 A 或者 C (A') 位置 */
        case TIMER_EVENT_CAPTURE_A:
            /*测频——上升沿捕获+1*/
            pulse_up_count++;
						pulse_up_count_1s++;
            break;
        
        /* 捕获到下降沿 -- 是 B 位置 */
        case TIMER_EVENT_CAPTURE_B:

            break;
        
        /* 定时器计数溢出事件 */
        case TIMER_EVENT_CYCLE_END://溢出0.5s
            overflow_times++;
            /* 输入捕获期间计数器溢出，则记录溢出次数+1 */
            if(overflow_times==10) {
                pulse_count=pulse_up_count;
                pulse_up_count=0;//脉冲计数清0
                overflow_times=0;
            }
						if(overflow_times%2==0){
								pulse_1s=pulse_up_count_1s;
							pulse_up_count_1s=0;
						}
            LED1_TOGGLE;
            break;
        
        default:
            break;
    }
}
