#if !defined(__UART3_DISPLAY_H__)
#define __UART3_DISPLAY_H__

#include "hal_data.h"
#include <stdint.h> //包含printf()函数需要的头文件
static volatile int g_uart3_tx_complete = 0;

void uart3_init(void);
void uart3_callback(uart_callback_args_t * p_args);
void uart3_wait_for_tx(void);
void u3_printf(uint16_t lcd_addr, uint16_t data,unsigned char *data_str);
#endif // __UART3_DISPLAY_H__
