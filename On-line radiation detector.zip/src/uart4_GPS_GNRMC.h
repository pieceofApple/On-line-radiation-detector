#if !defined(__UART4_GPS_GNRMC_H__)
#define __UART4_GPS_GNRMC_H__

#include "hal_data.h"
#include <stdint.h> //包含printf()函数需要的头文件
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void uart4_init(void);
void uart4_callback(uart_callback_args_t * p_args);
void uart4_wait_for_tx(void);
void parse_GNRMC(const char *message, float *latitude, float *longitude, float *speed, char *time, char *date, int *year, int *month, int *day, int *hour, int *minute, int *second);
void get_GNRMC_message(void);
#endif // __UART4_GPS_GNRMC_H__
