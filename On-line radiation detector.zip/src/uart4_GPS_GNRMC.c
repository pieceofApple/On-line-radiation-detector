#include "uart4_GPS_GNRMC.h"
volatile int receive_begin=0;
volatile unsigned char GNRMC_message[100];
volatile unsigned char GNRMC_message_save[100];
unsigned int i;
float latitude, longitude, speed;
int year, month, day, hour, minute, second;
volatile unsigned int g_uart4_tx_complete = 0;
volatile unsigned int GNRMC_receive_complete=0;
const char *start_str = "$GNRMC";
void uart4_init(void)
{
    fsp_err_t err;
    /* 配置串口 */
    err = g_uart4.p_api->open(g_uart4.p_ctrl, g_uart4.p_cfg);
}
void uart4_callback(uart_callback_args_t * p_args)
{
    switch (p_args->event)
    {
        case UART_EVENT_TX_COMPLETE:
        {
            g_uart4_tx_complete  = 1;
            break;
        }
        case UART_EVENT_RX_CHAR:
        {
						if((uint8_t)p_args->data==36){
								receive_begin=1;
						}
						if(receive_begin==1) {
								if((uint8_t)p_args->data==10){//换行符
									receive_begin=0;
									i=0;
                                    if(strstr(GNRMC_message, start_str) != NULL)
                                    {
                                        GNRMC_receive_complete=1;
                                        // 使用 memcpy 函数将 GNRMC_message 复制到 GNRMC_message_save
                                        memcpy(GNRMC_message_save, GNRMC_message, sizeof(GNRMC_message));
                                    }
								}
								else{
										GNRMC_message[i]=(uint8_t)p_args->data;
										i++;
								}
						}
            break;
        }
        default:
        {
            break;
        }
    }
}

void uart4_wait_for_tx(void)
{
    while (!g_uart4_tx_complete);
    g_uart4_tx_complete = 0;
}
// Function to parse GNRMC message
void parse_GNRMC(const char *message, float *latitude, float *longitude, float *speed, char *time, char *date, int *year, int *month, int *day, int *hour, int *minute, int *second) {
    char *token;
    char copy[100];
    strcpy(copy, message);

    // Split the message by comma delimiter
    token = strtok(copy, ",");
    int count = 0;
    while (token != NULL) {
        if (count == 1) {
            strcpy(time, token); // Save time as string
            // Extract hour, minute, and second from time string
            sscanf(time, "%2d%2d%2d", hour, minute, second);
        } else if (count == 9) {
            strcpy(date, token); // Save date as string
            // Extract day, month, and year from date string
            sscanf(date, "%2d%2d%2d", day, month, year);
        } else if (count == 3) {
            *latitude = atof(token)/100; // Convert latitude to float
        } else if (count == 5) {
            *longitude = atof(token)/100; // Convert longitude to float
        } else if (count == 7) {
            *speed = atof(token); // Convert speed to float
        }
        token = strtok(NULL, ",");
        count++;
    }
}

void get_GNRMC_message(void)
{
    if(GNRMC_receive_complete)
    {
        char time[10], date[10];
        parse_GNRMC(GNRMC_message_save, &latitude, &longitude, &speed, time, date, &year, &month, &day, &hour, &minute, &second);
        /*百度、谷歌格式的经纬度*/
        latitude=(int)latitude+(latitude-(int)latitude)*100/60.0;
        longitude=(int)longitude+(longitude-(int)longitude)*100/60.0;
        //年份
        year=year+2000;
        R_SCI_UART_Close(g_uart4.p_ctrl);//完成一次GPS信息解析就暂停GPS_串口接收中断，防止频繁中断-->等待下次定时器内开启
        GNRMC_receive_complete=0;
    }
}