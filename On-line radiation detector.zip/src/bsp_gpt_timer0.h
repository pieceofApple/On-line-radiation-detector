#if !defined(__BSP_GPT_TIMER0_H__)
#define __BSP_GPT_TIMER0_H__

#include "hal_data.h"



void GPT0_Init(void);
void gpt_timer0_callback(timer_callback_args_t * p_args);

#endif // __BSP_GPT_TIMER0_H__
