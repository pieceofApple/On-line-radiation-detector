#include <stdio.h>
#include "hal_data.h"

extern void uart5_wait_for_tx(void);

/* 重写这个函数,重定向printf */
int fputc(int ch, FILE * f)
{
     (void)f;

     /* 启动发送字符 */
     g_uart5.p_api->write(g_uart5.p_ctrl, (uint8_t const * const)&ch, 1);

     /* 等待发送完毕 */
     uart5_wait_for_tx();

     return ch;
}


