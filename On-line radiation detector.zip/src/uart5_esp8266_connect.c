#include "uart5_esp8266_connect.h"

void uart5_init(void)
{
    fsp_err_t err;
    /* 配置串口 */
    err = g_uart5.p_api->open(g_uart5.p_ctrl, g_uart5.p_cfg);
}
void uart5_callback(uart_callback_args_t * p_args)
{
    switch (p_args->event)
    {
        case UART_EVENT_TX_COMPLETE:
        {
            g_uart5_tx_complete  = 1;
            break;
        }
        case UART_EVENT_RX_CHAR:
        {
            break;
        }
        case UART_EVENT_RX_COMPLETE:
        {

            break;
        }
        default:
        {
            break;
        }
    }
}

void uart5_wait_for_tx(void)
{
    while (!g_uart5_tx_complete);
    g_uart5_tx_complete = 0;
}
void connect_esp8266()
{
	///////////thingscloud物联网平台连接//////////	
	//-----发送指令，让ESP8266连接到阿里云----------注意由于延时的原因，需要等待一下
	printf("AT+RST\r\n");	//第0步复位  
    R_BSP_SoftwareDelay(1, 0.5*BSP_DELAY_UNITS_SECONDS);						
	
	printf("AT+CWMODE=1\r\n");	 //第1步设置模式  
    R_BSP_SoftwareDelay(1, 1*BSP_DELAY_UNITS_SECONDS);			
	
	printf("AT+CIPSNTPCFG=1,8,\"sh-3-mqtt.iot-api.com\"\r\n");	 //第2步网站连接
    R_BSP_SoftwareDelay(1, 2*BSP_DELAY_UNITS_SECONDS);		
	
	printf("AT+CWJAP=\"WLAN-ESP\",\"18507253901JSX\"\r\n"); //第3步WIFI热点名称，密码	
    R_BSP_SoftwareDelay(1, 5*BSP_DELAY_UNITS_SECONDS);	
	
	//第4步设备标识符、设备密钥
	printf("AT+MQTTUSERCFG=0,1,\"thingscloud\",\"mltzfqx05hnze0ju\",\"QSL1lzHfe0\",0,0,\"\"\r\n");
    R_BSP_SoftwareDelay(1, 3*BSP_DELAY_UNITS_SECONDS);
	
	//第5步网站网关
	printf("AT+MQTTCONN=0,\"sh-3-mqtt.iot-api.com\",1883,1\r\n");
    R_BSP_SoftwareDelay(1, 2*BSP_DELAY_UNITS_SECONDS);
	
	//第6步订阅网站下发指令
	printf("AT+MQTTSUB=0,\"attributes/push\",1\r\n");//订阅主题，可接收云端下发指令
    R_BSP_SoftwareDelay(1, 3*BSP_DELAY_UNITS_SECONDS);
}