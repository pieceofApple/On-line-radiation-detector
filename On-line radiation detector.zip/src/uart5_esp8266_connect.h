#if !defined(__UART5_ESP8266_CONNECT_H__)
#define __UART5_ESP8266_CONNECT_H__

#include "hal_data.h"
#include <stdint.h> //包含printf()函数需要的头文件
static volatile int g_uart5_tx_complete = 0;

void uart5_init(void);
void connect_esp8266(void);
void uart5_callback(uart_callback_args_t * p_args);
void uart5_wait_for_tx(void);

#endif // __ESP8266_CONNECT_H__
