#include "uart3_display.h"

void uart3_init(void)
{
    fsp_err_t err;
    /* 配置串口 */
    err = g_uart3.p_api->open(g_uart3.p_ctrl, g_uart3.p_cfg);
}
void uart3_callback(uart_callback_args_t * p_args)
{
    switch (p_args->event)
    {
        case UART_EVENT_TX_COMPLETE:
        {
            g_uart3_tx_complete  = 1;
            break;
        }
        case UART_EVENT_RX_CHAR:
        {
            
            break;
        }
        default:
        {
            break;
        }
    }
}

void uart3_wait_for_tx(void)
{
    while (!g_uart3_tx_complete);
    g_uart3_tx_complete = 0;
}

void draw_line(uint16_t data)
{
	uint8_t data_H=(data >> 8) & 0xFF ; // 取高8位;
	uint8_t data_L= data & 0xFF       ;  // 取高8位;
	uint8_t send_data[]={0x5a,0xa5,0x0d,0x82,0x03,0x10,0x5a,0xa5,0x01,0x00,0x00,0x02,data_H,data_L,data_H,data_L};//16个
	send_data[12]= data_H;
	send_data[13]= data_L;
	send_data[14]= data_H;
	send_data[15]= data_L;
	/* 启动发送字符 */
	g_uart3.p_api->write(g_uart3.p_ctrl, send_data, 16);
	/* 等待发送完毕 */
	uart3_wait_for_tx();
}
	
void u3_printf(uint16_t lcd_addr, uint16_t data,unsigned char *data_str)
{
    uint8_t cmd_1=0x5A;
    uint8_t cmd_2=0xA5;
    uint8_t cmd_3=0x0D;
    uint8_t cmd_4=0x82;
    
    uint8_t lcd_addr_H =(lcd_addr >> 8) & 0xFF ; // 取高8位;
    uint8_t lcd_addr_L = lcd_addr & 0xFF       ;  // 取高8位;

    uint8_t data_H=(data >> 8) & 0xFF ; // 取高8位;
    uint8_t data_L= data & 0xFF       ;  // 取高8位;
    


    uint8_t send_data[]={cmd_1,cmd_2,cmd_3,cmd_4,lcd_addr_H,lcd_addr_L,data_H,data_L,0X00,0X00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
		if(lcd_addr==0x1010 || lcd_addr==0x2020)
		{
			send_data[6]= data_str[0];
			send_data[7]= data_str[1];
			send_data[8]= data_str[2];
			send_data[9]= data_str[3];
			send_data[10]= data_str[4];
			send_data[11]= data_str[5];

			/* 启动发送字符 */
			g_uart3.p_api->write(g_uart3.p_ctrl, send_data, 14);
			/* 等待发送完毕 */
			uart3_wait_for_tx();
		}
		else if(lcd_addr==0x1400 || lcd_addr==0x0500)
		{
			send_data[6]= data_str[0];
			send_data[7]= data_str[1];
			send_data[8]= data_str[2];
			send_data[9]= data_str[3];
			send_data[10]=data_str[4];
			send_data[11]=data_str[5];
			send_data[12]=data_str[6];
			send_data[13]=data_str[7];
			send_data[14]=data_str[8];
			send_data[15]=data_str[9];
			/* 启动发送字符 */
			g_uart3.p_api->write(g_uart3.p_ctrl, send_data, 18);
			/* 等待发送完毕 */
			uart3_wait_for_tx();
		}
		else if(lcd_addr==0x0310)
		{
			draw_line(data);
		}
		else
		{
			if(lcd_addr==0x0300) data=data;
			send_data[6]= data_H;
			send_data[7]= data_L;
			/* 启动发送字符 */
			g_uart3.p_api->write(g_uart3.p_ctrl, send_data, 8);
			/* 等待发送完毕 */
			uart3_wait_for_tx();
		}

}
