#include "bsp_gpt_timer0.h"

#define NUM_VALUES 12 // 存储前几个辐射值的数组大小

uint16_t count;
uint16_t count_2;
uint16_t count_GPS;

uint16_t flag_send;
uint8_t currentIndex;
extern volatile uint32_t pulse_up_count;
extern volatile uint32_t pulse_count;
extern volatile uint32_t pulse_1s;

volatile int arry_pulse[NUM_VALUES]={0};

extern volatile float latitude;//纬度
extern volatile float longitude;//经度
extern volatile int hour;
extern volatile int minute;
extern volatile int second;

void GPT0_Init(void)
{
    /* 初始化 GPT0 模块 */
    R_GPT_Open(g_timer0.p_ctrl, g_timer0.p_cfg);
    /* 启动 GPT0 定时器 */
    R_GPT_Start(g_timer0.p_ctrl);

    count=0;
}


// 计算数组中元素的平均值
float calculateAverage(int arr[], int size) {
    float sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return sum / size;
}

// 更新连续平均值
void updateContinuousAverage(int arr[], int size, int newValue, int *currentIndex) {
    // 更新当前索引位置的值
    arr[*currentIndex] = newValue;
    // 更新索引，如果超出数组边界则循环使用数组空间
    *currentIndex = (*currentIndex + 1) % size;
}


void gpt_timer0_callback(timer_callback_args_t * p_args)
{
	if(p_args->event == TIMER_EVENT_CYCLE_END)
	{
		count++;
		count_2++;
		count_GPS++;
		char str_float[20]; // 选择足够大的缓冲区来存储转换后的字符串
		
		if(count_GPS==10)
		{
			printf("AT+MQTTPUB=0,\"attributes\",\"{\\\"lat\\\":%f}\",0,0\r\n",latitude);
		}
		if(count_GPS==15)
		{
			printf("AT+MQTTPUB=0,\"attributes\",\"{\\\"lng\\\":%f}\",0,0\r\n",longitude);
			count_GPS=0;
		}
		if(count==5)//5s发送一次
		{
			count=0;
			float radiation;
			// 更新连续平均值
      updateContinuousAverage(arry_pulse, NUM_VALUES, pulse_count, &currentIndex);
			pulse_count = calculateAverage(arry_pulse, NUM_VALUES);
			//radiation = 1.2345;
			radiation=pulse_count/263.0;//每5s 14脉冲为1usf/f  0.1
			sprintf(str_float, "%.4f", radiation);
			u3_printf(0x2020,0,str_float);//0x2020-->平均辐射
			
			//GPS信息//0x0400-->经度，0x0500-->纬度 字符串发送
			sprintf(str_float, "%.6f", longitude);
			u3_printf(0x1400,0,str_float);
			u3_printf(0x1400,0,str_float);
			sprintf(str_float, "%.6f", latitude);
			u3_printf(0x0500,0,str_float);
			
			printf("AT+MQTTPUB=0,\"attributes\",\"{\\\"radiation\\\":%f}\",0,0\r\n",radiation);
		}
		
		if(count_2==2)
		{
		//2s发送一次
			count_2=0;
			float radiation_1s;//0.125
			radiation_1s=pulse_1s/60.0000;
			//radiation_1s=1.234;
			sprintf(str_float, "%.4f", radiation_1s);
			u3_printf(0x1010,0,str_float);//0x1010-->瞬时辐射 字符串发送
			u3_printf(0x1010,0,str_float);//瞬时辐射---串口屏第一次发送接收不到需要发两次

			//发送16进制数据
			hour=(hour+8)%24;
			u3_printf(0x0100,hour,0);//0x0100-->小时，0x0200-->分，0x0300-->秒
			u3_printf(0x0400,minute,0);
			u3_printf(0x0400,minute,0);
			
			u3_printf(0x0300,second,0);
			
			volatile uint16_t radiation_100=pulse_1s*10/60;
			u3_printf(0x0310,radiation_100,0);
			
			flag_send=1;
			R_SCI_UART_Open(g_uart4.p_ctrl, g_uart4.p_cfg);//每1s重新开启串口4——GPS（每次成功接收GPS_GNRMC信息后会关闭串口中断防止频繁接收中断）
    }
	}
}